# FOOTER
#ok banda hoy hare un vaso, un recipiente en python
import pygame, sys
import numpy as np
import math
from button import Button
from corregidor import Corregidor
def get_font(size): # Returns Press-Start-2P in the desired size
    return pygame.font.SysFont("f", size)

class Footer:
    #   CLASE: FOOTER
    # ATRIBUTOS
    #   WIDTH,HEIGHTDIMENSIONES DE LA PANTALLA
    #   DARK_PALETTE: DICCIONARIO DE COLORES
    #   FW,FH:DIMENSIONES DEL FOOTER
    #   OFFSET: DISTANDIA ENTRE EL FOOTER Y EL PANEL DEL FOOTER
    #   IPFW,IPFH: DIMENSIONES DEL PANEL INTERNO
    #   PPX,PPY: COORDENADAS DEL JUGADOR
    #   IPFPW:
    # ACCIONES
    #   SHOW: dibuja elementos sobre la pantalla
    #   PLAYER POS: RECIBE COORDENADAS DEL ARCHIVO PRINCIPAL
    #   SET_BUTTONS: ESTE METODO ES ACCIONADO POR EL MOUSE/CURSOR
    def __init__(self,WIDTH,HEIGHT):
        self.WIDTH,self.HEIGHT = WIDTH,HEIGHT
        self.dark_palette_5 = {
                    'h1':'#f79256',
                    'h2':'#fbd1a2',
                    'h3':'#7dcfb6',
                    'h4':'#00b2ca',
                    'h5':'#1d4e89'
                    }
        
        self.FW,self.FH = WIDTH,50
        self.offset = 5
        self.IPFW,self.IPFH = 200,self.FH-2*self.offset
        self.IBPW = 50

        #THE PLAYER POS
        self.ppx,self.ppy = 100,100
        self.IPFPW = 160
        
    def show(self,screen,mouse):
        self.font = pygame.font.SysFont('Comic Sans MS', 20)
        pygame.draw.rect(screen,self.dark_palette_5['h4'],(0,self.HEIGHT-self.FH,self.FW,self.FH))# The Footer
        pygame.draw.rect(screen,self.dark_palette_5['h2'],(self.WIDTH-self.offset-self.IPFW,self.HEIGHT-self.offset-self.IPFH,self.IPFW,self.IPFH))# IPF
        textsurface = self.font.render(f'cur pos: {mouse}',False,'#FFFFFF')
        screen.blit(textsurface,(self.FW-self.IPFW,self.HEIGHT-self.IPFH))# cur pos
        pygame.draw.rect(screen,self.dark_palette_5['h2'],(self.WIDTH-self.offset-self.IPFW-self.offset-self.IPFPW,self.HEIGHT-self.offset-self.IPFH,self.IPFPW,self.IPFH))# IPF player
        player_pos_text = self.font.render(f'ply pos: {self.ppx},{self.ppy}',False,'#FFFFFF')
        screen.blit(player_pos_text,(self.FW-self.IPFW-self.offset-self.IPFPW,self.HEIGHT-self.IPFH))# player pos
        self.CLEAR_BUTTON = Button(image=None, pos=(self.FW-self.IPFW-self.offset-self.IPFPW-3*(self.offset+self.IBPW),self.HEIGHT-self.IPFH+20), 
                        text_input="CLEAR", font=get_font(20), base_color="White", hovering_color="Green")
        self.CLEAR_BUTTON.changeColor(mouse)
        self.CLEAR_BUTTON.update(screen)
        # 3 lineas obigatorias para escribir un boton
        self.UNDO_BUTTON = Button(image=None, pos=(self.FW-self.IPFW-self.offset-self.IPFPW-2*(self.offset+self.IBPW),self.HEIGHT-self.IPFH+20), 
                            text_input="UNDO", font=get_font(20), base_color="White", hovering_color="Green")
        self.UNDO_BUTTON.changeColor(mouse)
        self.UNDO_BUTTON.update(screen)

        # 3 lineas obigatorias para escribir un boton
        self.SAVE_BUTTON = Button(image=None, pos=(self.FW-self.IPFW-self.offset-self.IPFPW-1*(self.offset+self.IBPW),self.HEIGHT-self.IPFH+20), 
                            text_input="SAVE", font=get_font(20), base_color="White", hovering_color="Green")
        self.SAVE_BUTTON.changeColor(mouse)
        self.SAVE_BUTTON.update(screen)        

    def player_pos(self,x,y):
        self.ppx,self.ppy = x,y
    def set_buttons(self,mouse):
        if self.CLEAR_BUTTON.checkForInput(mouse):
            print('funciona')
        if self.UNDO_BUTTON.checkForInput(mouse):
            print('funciona')
        if self.SAVE_BUTTON.checkForInput(mouse):
            print('funciona')

    

class Header:
    def __init__(self,WIDTH,HEIGHT):
        self.WIDTH,self.HEIGHT = WIDTH,HEIGHT
        self.dark_palette_5 = {
                    'h1':'#f79256',
                    'h2':'#fbd1a2',
                    'h3':'#7dcfb6',
                    'h4':'#00b2ca',
                    'h5':'#1d4e89'
                    }
        # Main header dimensions
        self.HW,self.HH = WIDTH,100
        # THE INNER PANEL HEADER IPH
        self.offset = 5
        self.IPHW = self.HW- 2*self.offset
        self.IPHH = self.HH - 2*self.offset

    def show(self,screen,mouse):
        self.font = pygame.font.SysFont('Comic Sans MS', 20)
        pygame.draw.rect(screen,self.dark_palette_5['h4'],(0,0,self.HW,self.HH))# The Footer
        pygame.draw.rect(screen,self.dark_palette_5['h2'],(self.offset,self.offset,self.IPHW,self.IPHH))# IPF
        

class Statistic_panel:
    def __init__(self,WIDTH,HEIGHT):
        self.WIDTH,self.HEIGHT = WIDTH,HEIGHT
        self.dark_palette_5 = {
                    'h1':'#f79256',
                    'h2':'#fbd1a2',
                    'h3':'#7dcfb6',
                    'h4':'#00b2ca',
                    'h5':'#1d4e89'
                    }
        # Main header dimensions
        self.SPW,self.SPH = 200,self.HEIGHT-100-50
        # THE INNER PANEL HEADER IPH
        self.offset = 5
        self.IPSPW = self.SPW- 2*self.offset
        self.IPSPH = self.SPH - 2*self.offset
        self.isInfoactive = False
        self.H = 0
        self.C = 0
        self.O = 0
        self.N = 0
        self.mol_count = None
        self.mols = None
    def show(self,screen,mouse):
        self.font = pygame.font.SysFont('Comic Sans MS', 15)
        pygame.draw.rect(screen,self.dark_palette_5['h1'],(0,100,self.SPW,self.SPH))# The STATISTIC PANEK
        pygame.draw.rect(screen,self.dark_palette_5['h3'],(self.offset,100+self.offset,self.IPSPW,self.IPSPH))# INNER PANEL STATPANEL
        textsurface = self.font.render(f'new mol: C{self.C}H{self.H}O{self.O}N{self.N}',False,'#FFFFFF')
        screen.blit(textsurface,(self.offset*2,100+self.offset*2))# cur pos
        if self.mol_count is not None:
            for i in range(self.mol_count):
                if i != len(self.mols)-1:
                    q,w,e,r = self.H,self.C,self.O,self.N
                    if q == 0:
                        q = 2*w+2
                        textsurface = self.font.render(f'past mol: C{w}H{q}O{e}N{r}',False,'#FFFFFF')
                    else:
                        textsurface = self.font.render(f'past mol: C{w}H{q}O{e}N{r}',False,'#FFFFFF')
                    screen.blit(textsurface,(self.offset*2,100+self.offset*2+(i+1)*(16)))# cur pos
                    if e == 0 and r == 0:
                        textsurface = self.font.render(f'past mol: C{w}H{q}',False,'#FFFFFF')

    def get_molecule_info(self,H,C,O,N,mol_count,mols):
        self.isInfoactive = True
        self.H = H
        self.C = C
        self.O = O
        self.N = N
        self.mol_count = mol_count
        self.mols = mols
        
class Molecule_window:
    def __init__(self,WIDTH,HEIGHT):
        self.WIDTH,self.HEIGHT = WIDTH,HEIGHT
        self.x,self.y = self.WIDTH/2,self.HEIGHT/2
        self.MWW,self.MWH = 200,150
        self.offset = 5
        self.IPMWW,self.IPMWH = self.MWW-2*self.offset,self.MWH-2*self.offset
        self.cool_palette_5 = {
                    'h1':'#f79256',
                    'h2':'#fbd1a2',
                    'h3':'#7dcfb6',
                    'h4':'#00b2ca',
                    'h5':'#1d4e89'
                    }
        self.CLOSE_BUTTON = Button(image=None, pos=(self.x+self.MWW-2*self.offset,self.y+2*self.offset), 
                        text_input="X", font=get_font(20), base_color="Red", hovering_color="Green")
        self.SAVE_BUTTON = Button(image=None, pos=(self.x+self.offset+50,30+self.y+3*self.offset), 
                        text_input="+Guardar", font=get_font(20), base_color=self.cool_palette_5['h5'], hovering_color="Green")
    def show(self,screen,mouse):
        self.font = pygame.font.SysFont('Comic Sans MS', 18)
        pygame.draw.rect(screen,self.cool_palette_5['h1'],(self.x,self.y,self.MWW,self.MWH))# The STATISTIC PANEK
        pygame.draw.rect(screen,self.cool_palette_5['h2'],(self.x+self.offset,self.y+self.offset,self.IPMWW,self.IPMWH))# INNER PANEL STATPANEL
        text1 = self.font.render(f'Existe esta molecula?',False,self.cool_palette_5['h5'])
        screen.blit(text1,(self.x+self.offset,self.y+2*self.offset))# cur pos
        self.CLOSE_BUTTON.changeColor(mouse)
        self.CLOSE_BUTTON.update(screen)
        self.SAVE_BUTTON.changeColor(mouse)
        self.SAVE_BUTTON.update(screen)
    def set_close(self,mouse):
        if self.CLOSE_BUTTON.checkForInput(mouse):
            return False
        else:
            return True
    
     
    def set_buttons(self,mouse,corregidor):
        if self.SAVE_BUTTON.checkForInput(mouse):
            pass
    def get_molecule_info(self,mols,links,count):
        self.count = count
        self.mols = mols
        self.links = links

class Element_window:
    def __init__(self,WIDTH,HEIGHT):
        self.WIDTH,self.HEIGHT = WIDTH,HEIGHT
        self.x,self.y = self.WIDTH/2,self.HEIGHT/2
        self.MWW,self.MWH = 200,150
        self.offset = 5
        self.IPMWW,self.IPMWH = self.MWW-2*self.offset,self.MWH-2*self.offset
        self.cool_palette_5 = {
                    'h1':'#f79256',
                    'h2':'#fbd1a2',
                    'h3':'#7dcfb6',
                    'h4':'#00b2ca',
                    'h5':'#1d4e89'
                    }
        self.CLOSE_BUTTON = Button(image=None, pos=(self.x+self.MWW-2*self.offset,self.y+2*self.offset), 
                        text_input="X", font=get_font(20), base_color="Red", hovering_color="Green")
        self.SAVE_BUTTON = Button(image=None, pos=(self.x+self.offset+50,30+self.y+3*self.offset), 
                        text_input="+Guardar", font=get_font(20), base_color=self.cool_palette_5['h5'], hovering_color="Green")
    def show(self,screen,mouse):
        self.font = pygame.font.SysFont('Comic Sans MS', 18)
        pygame.draw.rect(screen,self.cool_palette_5['h1'],(self.x,self.y,self.MWW,self.MWH))# The STATISTIC PANEK
        pygame.draw.rect(screen,self.cool_palette_5['h2'],(self.x+self.offset,self.y+self.offset,self.IPMWW,self.IPMWH))# INNER PANEL STATPANEL
        text1 = self.font.render(f'Existe esta molecula?',False,self.cool_palette_5['h5'])
        screen.blit(text1,(self.x+self.offset,self.y+2*self.offset))# cur pos
        self.CLOSE_BUTTON.changeColor(mouse)
        self.CLOSE_BUTTON.update(screen)
        self.SAVE_BUTTON.changeColor(mouse)
        self.SAVE_BUTTON.update(screen)
    def set_close(self,mouse):
        if self.CLOSE_BUTTON.checkForInput(mouse):
            return False
        else:
            return True
    
     
    def set_buttons(self,mouse,corregidor):
        if self.SAVE_BUTTON.checkForInput(mouse):
            pass
    def get_molecule_info(self,mols,links,count):
        self.count = count
        self.mols = mols
        self.links = links
