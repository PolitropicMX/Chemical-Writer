#ok banda hoy hare un vaso, un recipiente en python
import pygame, sys
import numpy as np
import math
from atomo import *
import random
from bezier import Bezier
# Initialize the pygame
pygame.init()


#Create the screen
HEIGHT, WIDTH = 600,600
screen = pygame.display.set_mode((HEIGHT,WIDTH))
pygame.display.set_caption("Pygame project")
pygame.font.init()
font = pygame.font.SysFont('Comic Sans MS', 30)

#Create the clock
clock = pygame.time.Clock()

#Codeline for the image background
#background = pygame.image.load('')

font = pygame.font.Font('freesansbold.ttf',32)

bezier = Bezier()

##class Bezier:
##    def __init__(self):
##        self.bezier_memory = []
##        self.bezier_midpoints = []
##        self.count = 0
##    def add_link(self,point):
##        self.bezier_memory.append(np.array(point))
##        
##        if len(self.bezier_memory)%2 == 0:
##            self.count += 1
##            self.bezier_midpoints.append(np.array([random.randint(point[0]-20,point[0]+20),random.randint(point[1]-20,point[1]+20)]))
##            
##    def show(self):
        

def linear(xi,yi,xf,yf,t):
    x = (1-t)*xi+t*xf
    y = (1-t)*yi+t*yf
    return x,y
    

# variables
segundero = 0
cur_vel_x = 0
cur_vel_y = 0
cur_x = 100
cur_y = 100
# programare visualmente el diagrama de

x1 = random.randint(0,WIDTH)
y1 = random.randint(0,HEIGHT)
x2 = random.randint(0,WIDTH)
y2 = random.randint(0,HEIGHT)
m = (y2-y1)/(x2-x1)
if m < 0:
    xr = x2
    yr = y1
else:
    xr = x1
    yr = y2
if x1 > x2:
    xr = random.randint(x2,x1)
else:
    xr = random.randint(x1,x2)
if y1 > y2:
    yr = random.randint(y2,y1)
else:
    yr = random.randint(y1,y2)
    

print(x1,y1,x2,y2,m)



# Funciones de dibujo
def dot(xi,yi,r,color):
    pygame.draw.circle(screen,color,(xi,yi),r)
def line(xi,yi,xf,yf):
    pygame.draw.line(screen,(255,0,0),(xi,yi),(xf,yf),3)
def rect(xi,yi,w,h):
    pygame.draw.rect(screen,(255,255,255),(xi,yi,w,h))
def text(string,xi,yi):
    textsurface = font.render(string,False,(10,100,100))
    screen.blit(textsurface,(xi,yi))
def panel(xi,yi,string):
    w,h = 250,40
    pygame.draw.rect(screen,(25,25,255),(xi,yi,w,h))
    textsurface = font.render(string,False,(255,255,255))
    screen.blit(textsurface,(xi,yi))
def cursor(xi,yi):
    ri,re = 10,12
    pygame.draw.circle(screen,(0,0,0),(xi,yi),re)
    pygame.draw.circle(screen,(255,255,255),(xi,yi),ri)
def vaso(xi,yi,w,h,e):
    pygame.draw.rect(screen,(255,255,255),(xi,yi,w,h))
    pygame.draw.rect(screen,(0,0,0),(xi+e,yi,w-2*e,h-e))
    
aux = 1
#### INICIALIZADORES ####
X,Y,H,W = 100,100,500,300
while True:
    tiempo = pygame.time.get_ticks()
    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                pass
            if event.key == pygame.K_UP:
                pass
            if event.key == pygame.K_q:
                pass
            if event.key == pygame.K_w:
                cur_vel_y = -10
            if event.key == pygame.K_a:
                cur_vel_x = -10
            if event.key == pygame.K_x:
                pass
            if event.key == pygame.K_d:
                cur_vel_x = 10
            if event.key == pygame.K_s:
                cur_vel_y = 10
            if event.key == pygame.K_n:
                pass
            if event.key == pygame.K_t:
                bezier.add_link((random.randint(0,WIDTH),random.randint(0,HEIGHT)))
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_DOWN:
                pass
            if event.key == pygame.K_UP:
                pass
            if event.key == pygame.K_q:
                pass
            if event.key == pygame.K_w:
                cur_vel_y = 0
            if event.key == pygame.K_e:
                pass
            if event.key == pygame.K_r:
                pass
            if event.key == pygame.K_a:
                cur_vel_x = 0
            if event.key == pygame.K_s:
                cur_vel_y = 0
            if event.key == pygame.K_d:
                cur_vel_x = 0
            if event.key == pygame.K_f:
                pass
    screen.fill((0,0,0))
    # A partir de aqui dibujas
    #print(segundero)
##    dot(x1,y1,9,'yellow')
##    dot(x2,y2,9,'Green')
##    dot(cur_x,cur_y,9,'Red')
##    t = math.sin(segundero/50)**2# De 0 a 1
##    l1x,l1y = linear(x1,y1,cur_x,cur_y,t)
##    dot(l1x,l1y,9,'Red')
##    l2x,l2y = linear(cur_x,cur_y,x2,y2,t)
##    dot(l2x,l2y,9,'Red')
##    lcx,lcy = linear(l1x,l1y,l2x,l2y,t)
##    dot(lcx,lcy,9,'White')
##    old_x,old_y = x1,y1
##    fgh = 20
##    for i in range(0,fgh,1):
##        l1x,l1y = linear(x1,y1,cur_x,cur_y,i/fgh)
##        l2x,l2y = linear(cur_x,cur_y,x2,y2,i/fgh)
##        lcx,lcy = linear(l1x,l1y,l2x,l2y,i/fgh)
##        line(old_x,old_y,lcx,lcy)
##        old_x,old_y = lcx,lcy
        
    bezier.show(screen)    
    #cursor
    cur_x += cur_vel_x
    cur_y += cur_vel_y

    #Aqui termina el loop
    segundero = segundero + 1
    pygame.display.update()
    clock.tick(30)
