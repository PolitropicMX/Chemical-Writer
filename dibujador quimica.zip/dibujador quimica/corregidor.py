class Corregidor:
    def __init__(self):
        self.C,self.H,self.O,self.N = 0,0,0,0
    def count_elements(self,mols,links):
        self.H,self.C,self.O,self.N = 0,0,0,0
        mol_coors = set(mols)
        mol_coors = list(mol_coors)
        mol_links = set(links)
        mol_links = list(mol_links)
        canasta = ''
        a = []
        for i,string in enumerate(mol_coors):
            for pos,letra in enumerate(string):
                if letra == 'C':
                    self.C += 1
                elif letra == 'H':
                    self.H += 1
                elif letra == 'O':
                    self.O += 1
                elif letra == 'N':
                    self.N += 1
    def send_info_statpanel(self):
        return self.H,self.C,self.O,self.N
