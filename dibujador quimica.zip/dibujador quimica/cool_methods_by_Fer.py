class Cool_methods_by_Fer:
    # Este metodo toma una lista de np.arrays, cada np.array es un punto
    # que en este caso es 2D y me devuelve los 2 indices de los np.arrays con
    # el valor de x y y mas baajo y alto 
    @staticmethod
    def whoswho(listadearrays):
        canastaxb = 0
        canastayb = 0
        canastaxl = 1000
        canastayl = 1000
        whosthebigx = 'none'
        whosthelilx = 'none'
        whosthelily = 'none'
        whosthebigy = 'none'
        for i,j in enumerate(listadearrays):
            if len(listadearrays) != 0 and len(listadearrays) != 1:
                if j.x_pos >= canastaxb:
                    canastaxb = j.x_pos
                    whosthebigx = i
                if j.x_pos <= canastaxl:
                    canastaxl = j.x_pos
                    whosthelilx = i
                if j.y_pos >= canastayb:
                    canastayb = j.y_pos
                    whosthebigy = i
                if j.y_pos <= canastayl:
                    canastayl = j.y_pos
                    whosthelily = i
        x,y = canastaxl-20,canastayl-20
        return x,y
