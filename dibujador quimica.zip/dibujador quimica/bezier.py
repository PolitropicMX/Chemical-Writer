# Bezier
import pygame
import numpy as np
import math
import random
class Bezier:
    def __init__(self):
        self.bezier_memory = []
        self.bezier_midpoints = []
        self.count = 0
        self.bezier_points = 0
        self.range = 10
    def add_link(self,point):
        self.bezier_memory.append(np.array(point))
        self.bezier_points += 1
        if len(self.bezier_memory)%2 == 0:
            self.count += 1
            print(f'el count{self.count} y el points {self.bezier_points}')
            for i in range(self.count):
                xi = self.bezier_memory[2*i][0]
                yi = self.bezier_memory[2*i][1]
                xf = self.bezier_memory[2*i+1][0]
                yf = self.bezier_memory[2*i+1][1]
                if xi > xf and yi > yf:
                    self.bezier_midpoints.append(np.array([random.randint(xf-self.range,xi+self.range),random.randint(yf-self.range,yi+self.range)]))
                elif xi < xf and yi > yf:
                    self.bezier_midpoints.append(np.array([random.randint(xi-self.range,xf+self.range),random.randint(yf-self.range,yi+self.range)]))
                elif xi < xf and yi < yf:
                    self.bezier_midpoints.append(np.array([random.randint(xi-self.range,xf+self.range),random.randint(yi-self.range,yf+self.range)]))
                elif xi > xf and yi < yf:
                    self.bezier_midpoints.append(np.array([random.randint(xf-self.range,xi+self.range),random.randint(yi-self.range,yf+self.range)]))
    @staticmethod
    def linear(xi,yi,xf,yf,t):
        x = (1-t)*xi+t*xf
        y = (1-t)*yi+t*yf
        return x,y
    def show(self,screen):
        
        if self.bezier_points != 0:
            self.old_x,self.old_y = self.bezier_memory[0][0],self.bezier_memory[0][1]
            fgh = 20
            for i,j in enumerate(self.bezier_memory):
                pygame.draw.circle(screen,"#233978",j,9)
##            print(len(self.bezier_memory))
            for k in range(self.count):
                self.old_x,self.old_y = self.bezier_memory[2*k][0],self.bezier_memory[2*k][1]
##                print(k,len(self.bezier_midpoints))
##                if k != len(self.bezier_midpoints):
                for i in range(0,fgh,1):
                    l1x,l1y = self.linear(self.bezier_memory[2*k][0],self.bezier_memory[2*k][1],self.bezier_midpoints[k][0],self.bezier_midpoints[k][1],(i+1)/fgh)
                    l2x,l2y = self.linear(self.bezier_midpoints[k][0],self.bezier_midpoints[k][1],self.bezier_memory[2*k+1][0],self.bezier_memory[2*k+1][1],(i+1)/fgh)
                    lcx,lcy = self.linear(l1x,l1y,l2x,l2y,(i+1)/fgh)
                    pygame.draw.line(screen,'#EE4B2B',(self.old_x,self.old_y),(lcx,lcy),5)
                    self.old_x,self.old_y = lcx,lcy
            
