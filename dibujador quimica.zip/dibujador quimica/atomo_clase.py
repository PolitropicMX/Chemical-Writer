# CREAREMOS UN ATOMO UN CREADOR DE MOLECULAS
import pygame, sys
import numpy as np
import math
import random
from atomo import *
from furniture import Footer, Header, Statistic_panel, Molecule_window
from bezier import Bezier
from scrollmenu import Scrollmenu
from button import Button
from corregidor import Corregidor
# Initialize the pygame
pygame.init()
def get_font(size): # Returns Press-Start-2P in the desired size
    return pygame.font.SysFont("f", size)

#Create the screen
HEIGHT, WIDTH = 600,1000
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("Pygame project")
pygame.font.init()
font = pygame.font.SysFont('Comic Sans MS', 20)

#Create the clock
clock = pygame.time.Clock()

#Codeline for the image background
#background = pygame.image.load('')

font = pygame.font.Font('freesansbold.ttf',20)


# WIDGETS
footer = Footer(WIDTH,HEIGHT)
header = Header(WIDTH,HEIGHT)
statpanel = Statistic_panel(WIDTH,HEIGHT)
molwin = Molecule_window(WIDTH,HEIGHT)

# CLASE DE CORRECCION
# EN REVISION
corregidor = Corregidor()

# FUNCION DE DIBUJO
bezier = Bezier()

# variables
segundero = 0
cur_vel_x = 0
cur_vel_y = 0

# POSICION INICIAL DEL CURSOR Y PRIMER COORDENADA ATOM
cur_x = 300.0
cur_y = 200.0

# Funciones de dibujo
def dot(xi,yi,r):
    pygame.draw.circle(screen,(0,0,0),(xi,yi),r)
def line(xi,yi,xf,yf):
    pygame.draw.line(screen,(255,255,255),(xi,yi),(xf,yf),1)
def rect(xi,yi,w,h):
    pygame.draw.rect(screen,(255,255,255),(xi,yi,w,h))
def text(string,xi,yi):
    textsurface = font.render(string,False,(10,100,100))
    screen.blit(textsurface,(xi,yi))
def panel(xi,yi,string):
    w,h = 250,40
    pygame.draw.rect(screen,(25,25,255),(xi,yi,w,h))
    textsurface = font.render(string,False,(255,255,255))
    screen.blit(textsurface,(xi,yi))
def cursor(xi,yi):
    ri,re = 10,12
    pygame.draw.circle(screen,(0,0,0),(xi,yi),re)
    pygame.draw.circle(screen,(255,255,255),(xi,yi),ri)
def vaso(xi,yi,w,h,e):
    pygame.draw.rect(screen,(255,255,255),(xi,yi,w,h))
    pygame.draw.rect(screen,(0,0,0),(xi+e,yi,w-2*e,h-e))
    
add_atom = False# CONTROLA EL BOTON F PARA AÑADIR ATOMOS
the_coordinate = (0,0)
Lamezcla = Mezcla()
# CLASE: MEZCLA
    # ATRIBUTOS
    #   MOLECULES:#LISTA DE OBJETOS MOLECULE
    #   COUNT:VARIABLE QUE CONTABILIZA EL NUMERO DE OBJETOS MOLECULE
    #   LINKS:LISTA DE
    # ACCIONES
    #   ADD_MOLECULE: AÑADE OBJETOS MOLECULE A MOLECULES CON CONTABILIZACION
    #   ADD_LINKS: AÑADE ??? SIN CONTABILIZACION
    #   SHOW_MOLECULES: ITERA A TRAVES DE MOLECULES(LISTA DE OBJETOS MOLECULE)
    #       Y UTILIZA EL METODO SHOW_ATOMS PARA DISPLAYARSE
    #   SEND_STATISTICS: DEVUELVE COUNT(VARIABLE QUE CONTABILIZA EL NUMERO DE OBJETOS MOLECULE)
    #       MOLECULES Y LINKS
molecula = Molecule()
    # CLASE: MOLECULE
    # ATRIBUTOS
    #   ATOMS:LISTA DE OBJETOS CLASE ATOM
    #   MOLECULE:LISTA DE STRINGS QUE REPRESENTAN LOS ATRIBUTOS X Y Y DE ATOM
    #   RADIO: RADIO DEL OBJETO MOLECULE
    #   COLOR BASE
    #   COLOR CUANDO ES DETECTADO
    #   COUNT:EL NUMERO TOTAL DE ATOMOS
    #   LINKS:LISTA DE STRINGS, CADA STRING ES UNA COORDENADA 2D SEPARADA POR PUNTO
    #   SHOWMOLECULE: SE ACTIVA CUANDO SE AÑADE POR PRIMERA VEZ UN OBJETO DE LA CLASE ATOM
    #   ISACTIVE: SE DESACTIVA CUANDO TURNOFF_THIS_MOLECULE ES USADO
    #   MOL_X Y MOL_Y SON LAS COORDENADAS DE EL OBJETO MOLECULE
    #   VARIABLES COUNT: CONTEAN LA CLASIFICACION DE CADA ATOM
    # ACCIONES
    #   ADD_ATOM: AÑADE A ATOMS UN OBJETO DE LA CLASE ATOM
##############    # CLASE: ATOM
##############    # ATRIBUTOS
##############    #   X
##############    #   Y
##############    #   RADIO
##############    #   COLOR BASE
##############    #   COLOR CUANDO ES DETECTADO
##############    #   CLASIFICACION(ELEMENTO)
##############    # ACCIONES
##############    #   DIBUJARSE EN LA PANTALLA
##############    #   AVISAR SI EL CURSOR ESTA ENCIMA
    #       CONTEA POR NOMBRE CADA OBJETO ATOM POR SU ATRIBUTO ELEMENT
    #       CONTEA EL NUMERO DE OBJETOS AÑADIDOS
    #       CREA LAS COORDENADAS DEL OBJETO MOLECULE CON UN METODO DE LA CLASE
    #       COOL_METHODS_BY_FER
    #   CHANGE STATISTICS: RECIBE VALORES PARA LAS VARIABLES COUNT
    #   SEND_STATISTICS: DEVUELVE LAS VARIABLES COUNT
    #   SEND_LINKS: DEVUELVE
    #       MOLECULE:LISTA DE STRINGS QUE REPRESENTAN LOS ATRIBUTOS X Y Y DE ATOM
    #       LINKS:LISTA DE STRINGS, CADA STRING ES UNA COORDENADA 2D SEPARADA POR PUNTO
    #   SHOW_ATOMS: FUNCION DE DIBUJO
    #   TURNOFF_THIS_MOLECULE: CUANDO EL OBJETO MOLECULE ES CLICKEADO
    #       ESTE METODO SE ACTIVA, CAMBIA DE COLOR EL ULTIMO OBJETO AÑADIDO A NEGRO
    #       Y A PARTIR DE ATOMS CREA MOLECULE Y LINKS
Lamezcla.add_molecule(molecula)# SE AÑADE UN PRIMER OBEJTO MOLECULA
scrollmenu = Scrollmenu(screen,210)
ismenuRunning = False # SE ACTIVA SCROLLMENU POR LA TECLA E
isMolWinopen = False# SE ACTIVA CUANDO SE PRESIONA..DETECTA CUALQUIER ACCION CON EL MOUSE
fcount = 0
whatelement = ''
while True:
    
    tiempo = pygame.time.get_ticks()
    mouse = pygame.mouse.get_pos()
    pos = pygame.mouse.get_pos()
    scale = 40
    
    for event in pygame.event.get():
        
        if event.type == pygame.MOUSEBUTTONDOWN:# DETECTA CUALQUIER ACCION CON EL MOUSE
            for q,w in enumerate(Lamezcla.molecules):
                for index,atom in enumerate(w.atoms):
                    if atom.checkForInput(mouse):
                        the_coordinate = (int(atom.x_pos),int(atom.y_pos))
                        bezier.add_link(the_coordinate)
                    else:
                        pass
            if molecula.checkForInput(mouse):
                print('WHATS GOING ON ')
                
                isMolWinopen = True
                mlinks,mol = molecula.turnoff_this_molecule()
                corregidor.count_elements(mol,mlinks)# AQUI RECIBIO LA INFO
##                molwin.set_buttons(mouse,corregidor)
                Lamezcla.add_links(links)# DEVUELVE A CLASE MEZCLA 
                

                molecula = Molecule()
                Lamezcla.add_molecule(molecula)
            else:
                pass
            if event.button == 1:
                footer.set_buttons(mouse)
                isMolWinopen = molwin.set_close(mouse)
                
                if ismenuRunning:
                    if scrollmenu.controlspressed(pos) is None :
                        # cuando el argumento recibido sea un None
                        pass
                    elif 31 <= int(scrollmenu.controlspressed(pos)):
                        # Si por alguna razon el argumento es igual o mayor a
                        # 31, solo que siga la ventana abierta
                        ismenuRunning = True
##                    elif 14 == int(scrollmenu.controlspressed(pos)):
##                        # Cuando se añade un numero
##                    elif 15 == int(scrollmenu.controlspressed(pos)):
##                        # Cuando se añade un texto    
                    else:
                        # Si no es anda de lo anterior, significa que es menor a 31
                        # o igual a 0 asi que es valido y se guarda
                        ismenuRunning = False
                elif event.button == 2:
                    scrollmenu.for_button_2(pos)
        if event.type == pygame.MOUSEBUTTONUP:
            scrollmenu.controlsreleased(pos)
        if event.type == pygame.QUIT:
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                pass
            if event.key == pygame.K_UP:
                pass
            if event.key == pygame.K_e:# INVENTARIO
                ismenuRunning = True
            if event.key == pygame.K_UP:
                cur_y += -scale*math.sin(30/180*math.pi)
            if event.key == pygame.K_LEFT:
                cur_x += -scale*math.cos(30*(math.pi/180))
            if event.key == pygame.K_x:
                pass
            if event.key == pygame.K_RIGHT:
                cur_x += scale*math.cos(30*(math.pi/180))
            if event.key == pygame.K_DOWN:
                cur_y += scale*math.sin(30/180*math.pi)
            if event.key == pygame.K_t:
                pass
            if event.key == pygame.K_c:
                add_atom = True
                whatelement = 'C'
            if event.key == pygame.K_h:
                add_atom = True
                whatelement = 'H'
            if event.key == pygame.K_o:
                add_atom = True
                whatelement = 'O'
            if event.key == pygame.K_n:
                add_atom = True
                whatelement = 'N'
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_DOWN:
                pass
            if event.key == pygame.K_UP:
                pass
            if event.key == pygame.K_q:
                pass
            if event.key == pygame.K_w:
                cur_y += 0
            if event.key == pygame.K_e:
                pass
            if event.key == pygame.K_r:
                pass
            if event.key == pygame.K_a:
                cur_x += 0
            if event.key == pygame.K_s:
                cur_y += 0
            if event.key == pygame.K_d:
                cur_x += 0
            if event.key == pygame.K_f:
                pass
    screen.fill((255,255,255))
    # A partir de aqui dibujas
    #print(segundero)
    # AQUI RECOPILAMOS TODA LA INFORMACION DE LAS 3 CLASES: ATOM, MOLECULE, MEZCLA

    howmanymolecules,moleculas,links = Lamezcla.send_statistics()
##    print(HIDRO,CARBON,OXIGEN,NITRO)
##    statpanel.get_molecule_info(HIDRO,CARBON,OXIGEN,NITRO,howmanymolecules,moleculas)
    footer.player_pos(int(cur_x),int(cur_y))
    footer.show(screen,mouse)
    header.show(screen,mouse)
    statpanel.show(screen,mouse)
    if add_atom and whatelement != '':# para añadir desde el teclado un objeto atom a la clase molecule
        molecula.add_atom(Atom((cur_x,cur_y),whatelement,(0,255,0)))
        add_atom = False
        whatelement = ''
    bezier.show(screen)
        
    dot(cur_x,cur_y,9)
    
    #dibujas los atomos
    Lamezcla.show_molecules(screen,mouse)
##    molecula.show_atoms(screen,mouse)
           
    #cursor
    cur_x += cur_vel_x
    cur_y += cur_vel_y

    if ismenuRunning:# Cuando la ventana esta activa
        CLOSE_MENU_BUTTON.changeColor(mouse)
        CLOSE_MENU_BUTTON.update(screen)# Draw
        scrollmenu.update(pos)# Draw Menu
    if isMolWinopen:
        
        molwin.show(screen,mouse)
        try:
            molwin.get_molecule_info(mol,mlinks,howmanymolecules)
        except:
            pass
        HIDRO,CARBON,OXIGEN,NITRO = corregidor.send_info_statpanel()# AQUI DEVUELVE LA INFORMACION
        statpanel.get_molecule_info(HIDRO,CARBON,OXIGEN,NITRO,howmanymolecules,moleculas)
    #Aqui termina el loop
    segundero = segundero + 1
    pygame.display.update()
    clock.tick(30)
