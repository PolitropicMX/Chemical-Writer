# atom
import pygame
import numpy as np
from cool_methods_by_Fer import Cool_methods_by_Fer
class Atom():# clase boton
    # Descripcion: Al instanciar la clase en el codigo principal, se crean propiedades como
    # us posicion, una imagen o un texto y la fuente de la letra
    def __init__(self, pos, element, hovering_color):
        #pos es una lista, array o tupla
        # Los   DATOS PRINCIPALES SON LAS COORDENADAS EL RADIO Y LOS 2C CLORES
        self.x_pos = pos[0]
        self.y_pos = pos[1]
        self.radio = 9
        self.hovering_color =  hovering_color # base_color="#d7fcd4", hovering_color="White"
        self.element = element
        if element == 'H':
            self.base_color = "Gray"
        elif element == 'C':
            self.base_color = "Black"
        elif element == 'O':
            self.base_color = "Red"
        elif element == 'N':
            self.base_color = "Blue"
    def update(self,screen,position):
        
        # Descripcion: este metodo permite que desde el codigo principal se actualice la imagen principal del boton
        
        if position[0] in range(int(self.x_pos-9), int(self.x_pos+9)) and position[1] in range(int(self.y_pos-9),int(self.y_pos+9)):
            pygame.draw.circle(screen,self.hovering_color,(self.x_pos,self.y_pos),9)
        else:
            pygame.draw.circle(screen,self.base_color,(self.x_pos,self.y_pos),9)

    def checkForInput(self, position):
        # Descripcion: devuelve un booleano si el cursor esta sobre el espacio que engloba el boton
        if position[0] in range(int(self.x_pos-9), int(self.x_pos+9)) and position[1] in range(int(self.y_pos-9),int(self.y_pos+9)):
            return True
        return False
    # CLASE: ATOM
    # ATRIBUTOS
    #   X
    #   Y
    #   RADIO
    #   COLOR BASE
    #   COLOR CUANDO ES DETECTADO
    #   CLASIFICACION(ELEMENTO)
    # ACCIONES
    #   DIBUJARSE EN LA PANTALLA
    #   AVISAR SI EL CURSOR ESTA ENCIMA
    

class Molecule():
    # CLASE: MOLECULE
    # ATRIBUTOS
    #   ATOMS:LISTA DE OBJETOS CLASE ATOM
    #   MOLECULE:LISTA DE STRINGS QUE REPRESENTAN LOS ATRIBUTOS X Y Y DE ATOM
    #   RADIO: RADIO DEL OBJETO MOLECULE
    #   COLOR BASE
    #   COLOR CUANDO ES DETECTADO
    #   COUNT:EL NUMERO TOTAL DE ATOMOS
    #   LINKS:LISTA DE STRINGS, CADA STRING ES UNA COORDENADA 2D SEPARADA POR PUNTO
    #   SHOWMOLECULE: SE ACTIVA CUANDO SE AÑADE POR PRIMERA VEZ UN OBJETO DE LA CLASE ATOM
    #   ISACTIVE: SE DESACTIVA CUANDO TURNOFF_THIS_MOLECULE ES USADO
    #   MOL_X Y MOL_Y SON LAS COORDENADAS DE EL OBJETO MOLECULE
    #   VARIABLES COUNT: CONTEAN LA CLASIFICACION DE CADA ATOM
    # ACCIONES
    #   ADD_ATOM: AÑADE A ATOMS UN OBJETO DE LA CLASE ATOM
##############    # CLASE: ATOM
##############    # ATRIBUTOS
##############    #   X
##############    #   Y
##############    #   RADIO
##############    #   COLOR BASE
##############    #   COLOR CUANDO ES DETECTADO
##############    #   CLASIFICACION(ELEMENTO)
##############    # ACCIONES
##############    #   DIBUJARSE EN LA PANTALLA
##############    #   AVISAR SI EL CURSOR ESTA ENCIMA
    #       CONTEA POR NOMBRE CADA OBJETO ATOM POR SU ATRIBUTO ELEMENT
    #       CONTEA EL NUMERO DE OBJETOS AÑADIDOS
    #       CREA LAS COORDENADAS DEL OBJETO MOLECULE CON UN METODO DE LA CLASE
    #       COOL_METHODS_BY_FER
    #   CHANGE STATISTICS: RECIBE VALORES PARA LAS VARIABLES COUNT
    #   SEND_STATISTICS: DEVUELVE LAS VARIABLES COUNT
    #   SEND_LINKS: DEVUELVE
    #       MOLECULE:LISTA DE STRINGS QUE REPRESENTAN LOS ATRIBUTOS X Y Y DE ATOM
    #       LINKS:LISTA DE STRINGS, CADA STRING ES UNA COORDENADA 2D SEPARADA POR PUNTO
    #   SHOW_ATOMS: FUNCION DE DIBUJO
    #   TURNOFF_THIS_MOLECULE: CUANDO EL OBJETO MOLECULE ES CLICKEADO
    #       ESTE METODO SE ACTIVA, CAMBIA DE COLOR EL ULTIMO OBJETO AÑADIDO A NEGRO
    #       Y A PARTIR DE ATOMS CREA MOLECULE Y LINKS
    def __init__(self):
        self.atoms = []# LA LISTA PRINCIPAL DONDE SE GUARDAN LOS OBJETOS DE LA CLASE ATOM
        self.molecule = []# LISTA DE STRINGS, CADA STRING ES UNA COORDENADA DE CADA OBJETO ATOM DE ATOMS
        self.radio = 9# EL RADIO DEL SEELECTOR DE MOLECULA
        self.base_color, self.hovering_color = "Blue","Green"
        self.count = 0# EL NUMERO TOTAL DE ATOMOS
        self.links = []# LISTA DE STRINGS, CADA STRING ES UNA COORDENADA 2D SEPARADA POR PUNTO
        self.showmolecule = False
        self.isActive = True
        self.mol_x,self.mol_y = Cool_methods_by_Fer.whoswho(self.atoms)
##        self.hidrogen_count,self.carbon_count,self.oxigen_count,self.nitrogen_count = 0,0,0,0

    def add_atom(self,atom):# AQUI SE AÑADEN LOS ATOMOS
        self.showmolecule = True
        self.atoms.append(atom)
##        if atom.element == 'H':
##            self.hidrogen_count += 1
##        elif atom.element == 'C':
##            self.carbon_count += 1
##        elif atom.element == 'O':
##            self.oxigen_count += 1
##        elif atom.element == 'N':
##            self.nitrogen_count += 1
        self.count += 1
        #buscamos los valores x y y mas altos y bajos
        self.mol_x,self.mol_y = Cool_methods_by_Fer.whoswho(self.atoms)
        

##    def change_statistics(self,h,c,o,n):
##        self.hidrogen_count,self.carbon_count,self.oxigen_count,self.nitrogen_count = h,c,o,n
##    def send_statistics(self):
##        return self.hidrogen_count,self.carbon_count,self.oxigen_count,self.nitrogen_count 
        
    def show_atoms(self,screen,mouse):# THE METHOD WHERE IT IS EVERYTHING BOUT DISPLAY
        if len(self.atoms) != 0 and len(self.atoms) != 1:
            pygame.draw.circle(screen,self.base_color,(self.mol_x,self.mol_y),self.radio)
        if self.showmolecule:
            if mouse[0] in range(int(self.mol_x-9), int(self.mol_x+9)) and mouse[1] in range(int(self.mol_y-9),int(self.mol_y+9)):
                pygame.draw.circle(screen,self.hovering_color,(self.mol_x,self.mol_y),9)
            else:
                pygame.draw.circle(screen,self.base_color,(self.mol_x,self.mol_y),9)
        for i,j in enumerate(self.atoms):
            j.update(screen,mouse)
            if i != 0:
                pygame.draw.line(screen,"Black",(self.atoms[i-1].x_pos,self.atoms[i-1].y_pos),(self.atoms[i].x_pos,self.atoms[i].y_pos),5)
                
        if self.isActive:
            if len(self.atoms) != 0:
                pygame.draw.circle(screen,"Red",(self.atoms[len(self.atoms)-1].x_pos,self.atoms[len(self.atoms)-1].y_pos),self.radio)
    def turnoff_this_molecule(self):# AQUI ES DONDE PRACTICAMENTE SE ESCRIBE LA MOLECULA
        self.isActive = False
        for i,j in enumerate(self.atoms):
            self.molecule.append(f'{self.atoms[i].element},{self.atoms[i].x_pos-300},{self.atoms[i].y_pos-200}')
            if i != 0:
                self.links.append(f'{self.atoms[i-1].x_pos-300},{self.atoms[i-1].y_pos-200},{self.atoms[i].x_pos-300},{self.atoms[i].y_pos-200}')
        return self.links,self.molecule    
                


    def checkForInput(self, position):
        # Descripcion: devuelve un booleano si el cursor esta sobre el espacio que engloba el boton
        if position[0] in range(int(self.mol_x-9), int(self.mol_x+9)) and position[1] in range(int(self.mol_y-9),int(self.mol_y+9)):
            return True
        return False
class Mezcla:
    # CLASE: MEZCLA
    # ATRIBUTOS
    #   MOLECULES:#LISTA DE OBJETOS MOLECULE
    #   COUNT:VARIABLE QUE CONTABILIZA EL NUMERO DE OBJETOS MOLECULE
    #   LINKS:LISTA DE
    # ACCIONES
    #   ADD_MOLECULE: AÑADE OBJETOS MOLECULE A MOLECULES CON CONTABILIZACION
    #   ADD_LINKS: AÑADE ??? SIN CONTABILIZACION
    #   SHOW_MOLECULES: ITERA A TRAVES DE MOLECULES(LISTA DE OBJETOS MOLECULE)
    #       Y UTILIZA EL METODO SHOW_ATOMS PARA DISPLAYARSE
    #   SEND_STATISTICS: DEVUELVE COUNT(VARIABLE QUE CONTABILIZA EL NUMERO DE OBJETOS MOLECULE)
    #       MOLECULES Y LINKS
    def __init__(self):
        self.molecules = []#LISTA DE OBJETOS MOLECULE
        self.count = 0# VARIABLE QUE CONTABILIZA EL NUMERO DE OBJETOS MOLECULE
        self.links = []# LISTA DE 
    def add_molecule(self,molecule):
        self.count += 1
        self.molecules.append(molecule)
    def add_links(self,links):
        self.links.append(links)

    def show_molecules(self,screen,mouse):
        for a,b in enumerate(self.molecules):
            b.show_atoms(screen,mouse)
    def send_statistics(self):
        return self.count,self.molecules,self.links

