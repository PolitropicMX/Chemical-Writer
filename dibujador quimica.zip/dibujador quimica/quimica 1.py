#ok banda hoy hare un vaso, un recipiente en python
import pygame, sys
import numpy as np
import math
# Initialize the pygame
pygame.init()


#Create the screen
HEIGHT, WIDTH = 600,600
screen = pygame.display.set_mode((HEIGHT,WIDTH))
pygame.display.set_caption("Pygame project")
pygame.font.init()
font = pygame.font.SysFont('Comic Sans MS', 30)

#Create the clock
clock = pygame.time.Clock()

#Codeline for the image background
#background = pygame.image.load('')

font = pygame.font.Font('freesansbold.ttf',32)


# variables
segundero = 0
cur_vel_x = 0
cur_vel_y = 0
cur_x = 100
cur_y = 100
# programare visualmente el diagrama de

diccionario = { 'Met': 1, 'Et': 2, 'Prop': 3 , 'but': 4}
print(diccionario['Met'])


# Funciones de dibujo
def dot(xi,yi,r):
    pygame.draw.circle(screen,(255,255,0),(xi,yi),r)
def line(xi,yi,xf,yf):
    pygame.draw.line(screen,(255,255,255),(xi,yi),(xf,yf),1)
def rect(xi,yi,w,h):
    pygame.draw.rect(screen,(255,255,255),(xi,yi,w,h))
def text(string,xi,yi):
    textsurface = font.render(string,False,(10,100,100))
    screen.blit(textsurface,(xi,yi))
def panel(xi,yi,string):
    w,h = 250,40
    pygame.draw.rect(screen,(25,25,255),(xi,yi,w,h))
    textsurface = font.render(string,False,(255,255,255))
    screen.blit(textsurface,(xi,yi))
def cursor(xi,yi):
    ri,re = 10,12
    pygame.draw.circle(screen,(0,0,0),(xi,yi),re)
    pygame.draw.circle(screen,(255,255,255),(xi,yi),ri)
def vaso(xi,yi,w,h,e):
    pygame.draw.rect(screen,(255,255,255),(xi,yi,w,h))
    pygame.draw.rect(screen,(0,0,0),(xi+e,yi,w-2*e,h-e))

# EYo tengo listas de elementos que quiero displayar en la pantalla asi que para tener guardados esos
# figurss creo la lista afuera y creo un funcion que añada elements a ese array
figuras = [] # Aqui se guarda el id de la figura y los puntos 2d ue la componen
def carbonmaker(a):
    roots = []
    wordcounter = 0
    
    for i,j in enumerate(a):
        if j == '-':
            roots.append(a[wordcounter:(i)])
            wordcounter = i+1
        if i == len(a)-1:
            roots.append(a[wordcounter:(i+1)])
    print(roots)
    return roots

def drawchemistry(roots,pos,scale):
    diccionario = { 'Met': 1,
                    'Et': 2,
                    'Prop': 3 ,
                    'But': 4,
                    'Pent': 5,
                    'Hex':6
                    }
    numeros = {
        '1':1,
        '2':2,
        '3':3,
        '4':4,
        '5':5,
        '6':6,
        '7':7,
        '8':8,
        '9':9}

    especie = {'ano':0,
               'eno':1,
               'ino':2,
               'ol':3,
               'aldehido':4}
    figura = []
    enlacepi = 0
    dondeenlacepi = None
    # Aqui es donde se colectan las palabras importantes
    for index,h in enumerate(roots):
        print(h)
        if h in diccionario:
            for i in range(diccionario[h]):
                figura.append(np.array([pos[0]+i*scale*math.cos(30*(math.pi/180)),pos[1]+(scale*math.sin(30/180*math.pi))*(i%2)]))
        elif h in especie:
            enlacepi = especie[h]
            dondeenlacepi = int(roots[index-1])-1
            if enlacepi == 2:# EN CONSTRUCCION
                for i in range(diccionario[h]):
                    figura.append(np.array([pos[0]+i*scale*math.cos(30*(math.pi/180)),pos[1]+(scale*math.sin(30/180*math.pi))*(i%2)]))
            if h == 'ol':
                ubi_alcohol = int(roots[index-1])-1# el elemento anterior a 'ol' en la nomenclatura quimica menos 1 para indexado de python arrays
                figura.append()
            
        else:
            pass
    for i,j in enumerate(figura):
        pygame.draw.circle(screen,(0,0,0),(j),9)# Carbonos
        if i != len(figura)-1:
            if i == dondeenlacepi:
                print(i)
                if (i+1)%2 == 0:
                    print("I'm even")
                    offset = np.array([2,2])
                else:
                    print("I'm odd")
                    offset = np.array([2,-2])
                pygame.draw.line(screen,(0,0,0),(j-offset),(figura[i+1]-offset),2)# enlace
                pygame.draw.line(screen,(0,0,0),(j+offset),(figura[i+1]+offset),2)
            else:
                pygame.draw.line(screen,(0,0,0),(j),(figura[i+1]),2)# enlace
aux = 1
#### INICIALIZADORES ####
X,Y,H,W = 100,100,500,300
while True:
    tiempo = pygame.time.get_ticks()
    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                pass
            if event.key == pygame.K_UP:
                pass
            if event.key == pygame.K_q:
                pass
            if event.key == pygame.K_w:
                cur_vel_y = -10
            if event.key == pygame.K_a:
                cur_vel_x = -10
            if event.key == pygame.K_x:
                pass
            if event.key == pygame.K_d:
                cur_vel_x = 10
            if event.key == pygame.K_s:
                cur_vel_y = 10
            if event.key == pygame.K_n:
                pass
            if event.key == pygame.K_f:
                pass
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_DOWN:
                pass
            if event.key == pygame.K_UP:
                pass
            if event.key == pygame.K_q:
                pass
            if event.key == pygame.K_w:
                cur_vel_y = 0
            if event.key == pygame.K_e:
                pass
            if event.key == pygame.K_r:
                pass
            if event.key == pygame.K_a:
                cur_vel_x = 0
            if event.key == pygame.K_s:
                cur_vel_y = 0
            if event.key == pygame.K_d:
                cur_vel_x = 0
            if event.key == pygame.K_f:
                pass
    screen.fill((255,255,255))
    if segundero == 0:
        entrada = input('>>>  ')
        roots = carbonmaker(entrada)
    drawchemistry(roots,[50,50],50)
    # A partir de aqui dibujas
    #print(segundero)
    

    #cursor
    cur_x += cur_vel_x
    cur_y += cur_vel_y
    #Aqui termina el loop
    segundero = segundero + 1
    pygame.display.update()
    clock.tick(30)
